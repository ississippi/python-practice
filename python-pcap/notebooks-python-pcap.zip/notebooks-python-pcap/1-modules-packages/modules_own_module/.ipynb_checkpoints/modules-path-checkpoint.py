import sys

sys.path.append('secret')

import secret_module

address = 'C:\\Users\\user\\..'
address_for_one = '..\\secret'