from project_modules.communication.com import my_fun

my_fun()