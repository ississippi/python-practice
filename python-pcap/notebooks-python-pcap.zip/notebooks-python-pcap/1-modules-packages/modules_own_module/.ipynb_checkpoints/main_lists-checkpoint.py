import lists_utils

my_list = [23, 21, 2, 5, 72]

print(lists_utils.sum_elements(my_list))