def my_fun():
    print('a')